// includes
const ejs     = require('ejs')
const routes  = require('./routes.js')
const express = require('express')

const app = express()


// app configuration
const PORT = 3000
app.set('view engine', 'ejs')
routes.setRoutes(app)
app.use('/', express.static('pages/static')) // makes the directory 'pages' completely public


// entry point
app.listen(PORT, function() {
  console.log('Server has been started')
})
