const VIEWS = __dirname + "/pages/"


module.exports = {
setRoutes: function(app) {
  // Mind map with routing:
  // https://www.mindmeister.com/2008826133/eagleboost-pages


  /*
    The directory 'static' is completely public.
    User can acess 'static' directory by '/' request
    It means, '/landing' will be interpritate as '/pages/static/landing'
    User can load all the paths and files contains in this directiory
  */



  // STATIC ----------------------------------------------------
  // redirecting to 'landing' from standart browser request
  app.get('/', function(req, res) {
    res.redirect('/landing')
  })
  app.get('/index', function(req, res) {
    res.redirect('/landing')
  })

  // redirecting to 'static/errno' from standart request
  app.get('/404', function(req, res) {
    res.redirect('/404.html')
  })
  app.get('/403', function(req, res) {
    res.redirect('/403.html')
  })

  app.get('/about_us', function(req, res) {
    res.redirect('/about_us')
  })
  // end STATIC ------------------------------------------------



  // EBMEDDABLE ----------------------------------------------------
  app.get('/calculator/:game', function(req, res) {
    res.render(VIEWS + 'embeddable/calculator/index.ejs', {game: req.params.game})
  })

  app.get('/members_area', function(req, res) {
    res.render(VIEWS + 'embeddable/members_area/index.ejs')
  })

  app.get('/payop', function(req, res) {
    res.render(VIEWS + 'embeddable/payop/index.ejs')
  })
  // end EMBEDDABLE ------------------------------------------------

}}
